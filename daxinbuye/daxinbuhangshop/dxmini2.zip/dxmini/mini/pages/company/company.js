import { request } from "../../request/index.js"

Page({

  /**
   * 页面的初始数据
   */
  data: {
    CompanyTem :[]
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
      this.getCompanyTem ()
  },
  //获取详情列表数据
    getCompanyTem () {
        request({ url: '/companyIntroduce/get'})
            .then(result => {   
                console.log(result)
                this.setData({ 
                  CompanyTem : result.data.data
                }) 
            })    
    },
})