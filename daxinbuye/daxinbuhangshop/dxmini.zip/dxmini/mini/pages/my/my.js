import Toast from '../../miniprogram_npm/@vant/weapp/toast/toast';
Page({
  data:{
   
  },
  //分享
  onShareAppMessage: function () {
      let that =this;
      return {
        title: '大新布行', // 转发后 所显示的title
        path: '/pages/my/my', // 相对的路径
        success: (res)=>{    // 成功后要做的事情
          console.log(res.shareTickets[0])
          // console.log
        
          wx.getShareInfo({
            shareTicket: res.shareTickets[0],
            success: (res)=> { 
              that.setData({
                isShow:true
              }) 
              console.log(that.setData.isShow)
            },
            fail: function (res) { console.log(res) },
            complete: function (res) { console.log(res) }
          })
        },
        fail: function (res) {
          // 分享失败
          console.log(res)
        }
      }
    },
    //轻提示
    test: function (){
      Toast.fail('敬请期待~');
    }

 })
