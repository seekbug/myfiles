import { request } from "../../request/index.js"
import Toast from '../../miniprogram_npm/@vant/weapp/toast/toast';

Page({
    data: {
        goodsObj: [],
        skuImageUrl: "",
        skuPrice:"",
        maxPrice:'',
        minPrice:'',
        show: false,
        id: 0
    },
    onLoad: function (options) {
        const { spuId } = options;
        this.getGoodsObj(spuId)   
    },
     //轻提示
     test: function (){
      Toast.fail('敬请期待~');
    },
     //分享
      onShareAppMessage: function () {
        let that =this;
        return {
          title: '大新布行', // 转发后 所显示的title
          path: '/pages/my/my', // 相对的路径
          success: (res)=>{    // 成功后要做的事情
            console.log(res.shareTickets[0])
            // console.log
          
            wx.getShareInfo({
              shareTicket: res.shareTickets[0],
              success: (res)=> { 
                that.setData({
                  isShow:true
                }) 
                console.log(that.setData.isShow)
              },
              fail: function (res) { console.log(res) },
              complete: function (res) { console.log(res) }
            })
          },
          fail: function (res) {
            // 分享失败
            console.log(res)
          }
        }
      },
    //选择色卡 锚点定位
    jumpTo:  function (e) {
      // 获取标签元素上自定义的 data-opt 属性的值
      let target = e.currentTarget.dataset.index;
      let index = e.currentTarget.dataset.id;
        // 2 修改源数组
        // 3 赋值到data中
        this.setData({
          toView: target,
          id:index
        })
    },
    //弹框
    showPopup(e) {
      let imageurl = e.currentTarget.dataset.imageurl;
      let price =  e.currentTarget.dataset.price;
      this.setData({ 
        show: true, 
        skuImageUrl: imageurl,
        skuPrice:price/100
       });
    },
    onClose() {
      this.setData({ show: false });
    },
    //标签页
    onChange(event) {
        wx.showToast({
          title: `切换到标签 ${event.detail.name}`,
          icon: 'none',
        });
      },
    //获取详情列表数据  
    getGoodsObj (spuId) {
        request({ url: '/spu/getGoodsById', data:{spuId}})
            .then(result => {
              let maxPrice = result.data.data.maxPrice/100;
              let minPrice = result.data.data.minPrice/100
                    this.setData({
                        goodsObj: result.data.data,
                        maxPrice,
                        minPrice 
                    })
            })
    },
})