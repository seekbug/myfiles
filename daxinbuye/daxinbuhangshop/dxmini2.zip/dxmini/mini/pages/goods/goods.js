import { request } from "../../request/index.js"
import {regeneratorRuntime} from '../../lib/runtime/runtime';
Page({
    data: {
        goodsLsit: [],
        menuLsit:[],
        //搜索列表
        goodsLsit_input:[],
        //左侧菜单点击
        activeKey: 0,
        //是否显示列表
        isShow:true
    },
     //接口要的参数
        queryForm: {
            category3Id: "",
            name: '',
            current: 1,
            size: 10,
        },
    //总页数
    totalpage:1,
    //防抖 定时器
    TimeId : -1,

    onLoad: function (e) {
        this. getGoodsLeftObj (),
        this. getGoodsRightObj ()
        this. getGoodsRightObj1()
    },
    //搜索框 点击清空时触发
    handleClear(e){
        this.setData({
            isShow:true
        })
    },
        //输入框的值改变了就会触发的事件
        handleInput(e){
            console.log(e)
            //获取输入框的值
            this.queryForm.name = e.detail
            //检测合法性
            // if(!this.queryForm.name.trim()){
            //     //值不合法
            //     return;  
            // } 
      
        //值为0时显示列表页
        if(this.queryForm.name == 0){
            console.log(999)
            this.setData({
                isShow:true
            })
        }else{
            //防抖
            clearTimeout(this.TimeId);
            this.TimeId = setTimeout(()=>{
                //准备发送请求获取数据
                this.getGoodsRightObj2();
            },1000); 
            this.setData({
                isShow:false
            })
        }
       
    },
    //左边菜单的点击事件
    handleItemTap (e) {
        // 获取分类id
        this.queryForm.category3Id = e.currentTarget.dataset.index
        //重新渲染
        this. getGoodsRightObj ()
    },
    //上滑 触底事件
    onReachBottom (){
        if (this.queryForm.current >= this.totalpage) {
            wx.showToast({
                title: '没有下一条',
            })
        } else {
            this.queryForm.current++
            this. getGoodsRightObj1() 
        }
   },
    //下拉刷新
    onPullDownRefresh () {
        console.log(11)
        this.setData({
            goodsList: [],
        })
        //3 重置页码
        this.queryForm.current = 1;
        // 重新发送请求
        this.getGoodsRightObj()
    },

    //获取右边列表数据
    async getGoodsRightObj () {
       const result = await request({ url: '/spu/pageFindPublished',data:this.queryForm});
            //计算总页数
            this.totalpage = Math.ceil(result.data.data.total / this.queryForm.size);
            this.setData({        
                goodsLsit: result.data.data.records,
            }) 
             //关闭下拉等待效果  如果没有下拉 这个关闭也不影响
             wx.stopPullDownRefresh();
    },
    async getGoodsRightObj1 () {
        const result = await request({ url: '/spu/pageFindPublished',data:this.queryForm});
             //计算总页数
             this.totalpage = Math.ceil(result.data.data.total / this.queryForm.size);
             this.setData({ 
                 //拼接的数组  旧数组,新数组
                 goodsLsit: [...this.data.goodsLsit,...result.data.data.records],
             }) 
     },
     async getGoodsRightObj2 () {
        const result = await request({ url: '/spu/pageFindPublished',data:this.queryForm});
             //计算总页数
             this.totalpage = Math.ceil(result.data.data.total / this.queryForm.size);
             this.setData({        
                 goodsLsit_input: result.data.data.records,
             }) 
              //关闭下拉等待效果  如果没有下拉 这个关闭也不影响
              wx.stopPullDownRefresh();
     },
    //获取详情左边菜单数据
    getGoodsLeftObj () {
        request({ url: '/category/listByLevel?level=3'})
            .then(result => {   
                this.setData({ 
                    menuLsit: result.data.data,
                }) 
            })    
    },

})