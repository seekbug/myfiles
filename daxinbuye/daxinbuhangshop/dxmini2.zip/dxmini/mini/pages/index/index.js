import { request } from "../../request/index.js"
 
const app = getApp()

Page({
  data: {
    swiperList:[],
    indexGroup_id:[],
    goodsCartLis:[],
    goodsCartLis1:[],
    goodsCartLis3:[],
    isShow:true,       
  },
    indexGroup:[],
    //接口要的参数
    queryForm: {
      category3Id: "",
      name: '',
      current: 1,
      size: 10,
    },
    //总页数
    totalpage:1,
    //防抖 定时器
    TimeId : -1,

    onLoad: function () {
        this.getIndexGroup();
        this.getSwiperList ();
        this.getGoodsCartList ();
        this.getGoodsCartList1 ();
        this.getGoodsCartList3 ();
    },
    //轮播图
    getSwiperList () {
      request({ url: '/module/carouselImage/listByModuleId?moduleId=4'})
          .then(result => {
                this.setData({
                  swiperList: result.data.data
                })
          })
      },
    //搜索框 点击清空时触发
    handleClear(e){
        this.setData({
            isShow:true
        })
    },
    //输入框的值改变了就会触发的事件
    handleInput(e){
      console.log(e)
      //获取输入框的值
      this.queryForm.name = e.detail
      //检测合法性
      // if(!this.queryForm.name.trim()){
      //     //值不合法
      //     return;  
      // } 

      //值为0时显示列表页
      if(this.queryForm.name == 0){
          console.log(999)
          this.setData({
              isShow:true
          })
      }else{
          //防抖
          clearTimeout(this.TimeId);
          this.TimeId = setTimeout(()=>{
              //准备发送请求获取数据
              this.getGoodsRightObj2();
          },1000); 
          this.setData({
              isShow:false
          })
      }
    },
  
 //商品卡片列表
 getGoodsCartList () {
  request({ url: '/module/goodsCardSpu/findPage?moduleId=' + 2 +"&pageIndex=" + 1 + "&pageSize=" + 4})
      .then(result => {
            this.setData({
              goodsCartLis: result.data.data.records
            })
      })
  },
  getGoodsCartList1 () {
    request({ url: '/module/goodsCardSpu/findPage?moduleId=' + 1 +"&pageIndex=" + 1 + "&pageSize=" + 4})
        .then(result => {
              this.setData({
                goodsCartLis1: result.data.data.records
              })
        })
    },
    getGoodsCartList3 () {
      request({ url: '/module/goodsCardSpu/findPage?moduleId=' + 3 +"&pageIndex=" + 1 + "&pageSize=" + 4})
          .then(result => {
                this.setData({
                  goodsCartLis3: result.data.data.records
                })
          })
      },
    //搜索列表
      async getGoodsRightObj2 () {
        const result = await request({ url: '/spu/pageFindPublished',data:this.queryForm});
             //计算总页数
             this.totalpage = Math.ceil(result.data.data.total / this.queryForm.size);
             this.setData({        
                 goodsLsit_input: result.data.data.records,
             }) 
              //关闭下拉等待效果  如果没有下拉 这个关闭也不影响
              wx.stopPullDownRefresh();
     },
    
  //列出小程序首页所有组件
  getIndexGroup () {
    request({ url: '/module/listMiniHome'})
        .then(result => {
          console.log(result)
              this.indexGroup= result.data.data
              let indexGroup_id = this.indexGroup.map(v => v.id);
              this.setData({
                indexGroup_id
              })
        })
    },
})
