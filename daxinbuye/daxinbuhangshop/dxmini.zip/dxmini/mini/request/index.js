//同时发送异步代码的次数
let ajaxTimes = 0;

export const request = (params) => {
  const baseUrl = "https://www.daxinbuye.com/api"
  return new Promise((resolve, reject) => {
       ajaxTimes++;
       //发送成功前显示图标
        wx.showLoading({
            title: '加载中',
            // mask:true
        })
      wx.request({
          ...params,
          url: baseUrl+params.url,
          success: (result) => {
              resolve(result);
          },
          fail: (err) => {
              reject(err);
          },
          complete:()=>{
            ajaxTimes--;
            if(ajaxTimes===0){
                //关闭正在等待的图标   
                wx.hideLoading();
            }        
          }
      });
  })
}


  
  